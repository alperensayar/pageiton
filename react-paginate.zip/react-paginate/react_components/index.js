import PaginationBoxView from './PaginationBoxView';

export default PaginationBoxView;
